package com.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.org.dao.CustomerDao;
import com.org.dto.Customer;

@Controller
public class CustomerController {

	@Autowired
	CustomerDao customerDao;

	@PostMapping("/add_customer")
	public ModelAndView saveAndUpdateCustomer(@ModelAttribute Customer customer) {
		ModelAndView mav = new ModelAndView("customer/add_customer.jsp");
		
		String str = customer.getCompanyName();
		String upperCase = str.substring(0,6).toUpperCase();
		
		customer.setId(upperCase);
		
		mav.addObject("success", "Customer Added Successfully");
		customerDao.saveCustomer(customer);
		return mav;

	}

	@GetMapping("/fetch_all_customers")
	public ModelAndView fetchALLCustomers() {

		ModelAndView mav = new ModelAndView("customer/view_customer.jsp");
		List<Customer> customers = customerDao.fetchAllCustomer();

		mav.addObject("customers", customers);

		return mav;
	}

}
