package com.org.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.org.dao.AdminDao;
import com.org.dto.Admin;

@Controller
public class AdminController {

	@Autowired
	AdminDao adminDao;
	
	@PostMapping("/admin_register")
	public ModelAndView saveAndUpdateAdmin(@ModelAttribute Admin admin)
	{
		ModelAndView mav = new ModelAndView("admin/admin_login.jsp");
		adminDao.saveAdmin(admin);
		return mav;
	
	}
	
	@PostMapping("/admin_login")
	public ModelAndView loginAdmin(@RequestParam String name, @RequestParam String password) {
		
		Admin admin = adminDao.fetchAdminByEmailAndPassword(name, password);
		
		if(admin != null) {
			ModelAndView mav = new ModelAndView("admin/admin_home.jsp");
			return mav;
			
		}
		ModelAndView mav = new ModelAndView("admin/admin_login.jsp");
		mav.addObject("fail", "Invalid Credentials");
		
		return mav;
	}
	
}
