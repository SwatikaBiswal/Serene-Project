package com.org.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Customer {
	
	@Id
	@Column(name="ID")
	private String id;
	
	private String companyName;
	
	private String contactName;
	
	private String contactTitle;
	
	private String region;
	
	private int postalCode;
	
	private String country;
	
	private String city;
	
	private long phone;
	
	private String fax;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn
	private Admin admin;

	public String getId() {
		return id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public String getContactName() {
		return contactName;
	}

	public String getContactTitle() {
		return contactTitle;
	}

	public String getRegion() {
		return region;
	}

	public int getPostalCode() {
		return postalCode;
	}

	public String getCountry() {
		return country;
	}

	public String getCity() {
		return city;
	}

	public long getPhone() {
		return phone;
	}

	public String getFax() {
		return fax;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public void setContactTitle(String contactTitle) {
		this.contactTitle = contactTitle;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public void setPostalCode(int postalCode) {
		this.postalCode = postalCode;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}
	
	
}
