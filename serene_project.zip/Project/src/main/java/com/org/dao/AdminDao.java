package com.org.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.org.dto.Admin;

@Component
public class AdminDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("karthik");

	EntityManager em = emf.createEntityManager();

	EntityTransaction et = em.getTransaction();

	public void saveAdmin(Admin admin) {
		et.begin();
		em.merge(admin);
		et.commit();
	}

	public Admin fetchAdminByEmailAndPassword(String name, String password) {
		Query query = em.createQuery("select u from Admin u where u.name=?1 and u.password=?2");
		query.setParameter(1, name);
		query.setParameter(2, password);
		
		List<Admin> admins = query.getResultList();
		
		if(admins.isEmpty())
			return null;
		
		return admins.get(0);
	}

}
