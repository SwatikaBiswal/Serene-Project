package com.org.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.org.dto.Customer;

@Component
public class CustomerDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("karthik");

	EntityManager em = emf.createEntityManager();

	EntityTransaction et = em.getTransaction();

	public void saveCustomer(Customer admin) {
		et.begin();
		em.merge(admin);
		et.commit();
	}
	
	public List<Customer> fetchAllCustomer(){
		
		Query query = em.createQuery("select c from Customer c");
		
		List<Customer> list = query.getResultList();
		
		return list;
		
	}

}
